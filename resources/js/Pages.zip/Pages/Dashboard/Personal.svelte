<script>
    import { useForm } from "@inertiajs/svelte";
    import { router } from "@inertiajs/svelte";
    import Input from "../../components/Input.svelte";
    import Modal from "../../components/Modal.svelte";
    import Table from "../../components/Table.svelte";
    import Alert from "../../components/Alert.svelte";
    import { displayAlert } from "../../stores/alertStore";
    import SelectableRow from "../../components/SelectableRow.svelte";

    export let types = [];
    export let data = [];
    let submitStatus = "Crear";

    console.log(data);
    const emptyDataForm = {
        type_user_id: 1,
        ci: "",
        name: "",
        last_name: "",
        email: "",
        phone_number: "",
        address: "",
        is_admin: false,
        email_verified_status: false,
    };

    let form = useForm({
        ...emptyDataForm,
    });

    let showModal = false;
    let selectedRow = { status: false, id: 0 };
    let editingUser = null;

    document.addEventListener("keydown", ({ key }) => {
        if (key === "Escape") {
            selectedRow = { status: false, id: 0 };
            editingUser = null;
            showModal = false;
        }
    });

    function loadUserData(user) {
        $form.reset();
        $form.fill({
            type_user_id: user.type_user_id || 1,
            ci: user.ci,
            name: user.name,
            last_name: user.last_name,
            email: user.email,
            phone_number: user.phone_number,
            address: user.address,
            is_admin: user.is_admin || false,
        });
        editingUser = user;
        submitStatus = "Editar";
        showModal = true;
    }

    function handleSubmit(event) {
        event.preventDefault();
        $form.clearErrors();
        if (submitStatus == "Crear") {
            $form.post("/dashboard/personal", {
                onError: (errors) => {
                    if (errors.message) {
                        displayAlert({
                            type: "error",
                            message: errors.message,
                        });
                    }
                },
                onSuccess: () => {
                    displayAlert({
                        type: "success",
                        message: "Usuario creado correctamente",
                    });
                    showModal = false;
                    editingUser = null;
                    $form.reset();
                },
            });
        } else if (submitStatus == "Editar") {
            $form.put(`/dashboard/personal/${editingUser.id}`, {
                onError: (errors) => {
                    if (errors.message) {
                        displayAlert({
                            type: "error",
                            message: errors.message,
                        });
                    }
                },
                onSuccess: (mensaje) => {
                    $form.reset();
                    displayAlert({
                        type: "success",
                        message: "Usuario actualizado correctamente",
                    });
                    showModal = false;
                    editingUser = null;
                    selectedRow = { status: false, id: 0 };
                },
            });
        }
    }

    function handleEdit() {
        showModal = true;
        editingUser = selectedRow.data;
        submitStatus = "Editar";

        const personal = selectedRow.data;
        $form.type_user_id = personal.type_user_id || 1;
        $form.ci = personal.ci;
        $form.name = personal.name;
        $form.last_name = personal.last_name;
        $form.email = personal.email;
        $form.phone_number = personal.phone_number;
        $form.address = personal.address;
        $form.is_admin = personal.is_admin || false;
        $form.email_verified_status = personal.email_verified_status || false;
    }

    function handleDelete() {
        const user = data.find((u) => u.id === selectedRow.data.id);
        if (
            user &&
            confirm(
                `¿Estás seguro de eliminar a ${user.name} ${user.last_name}?`,
            )
        ) {
            router.delete(`/dashboard/personal/${user.id}`, {
                onSuccess: () => {
                    displayAlert({
                        type: "success",
                        message: "Usuario eliminado correctamente",
                    });
                    selectedRow = { status: false, data: {} };
                },
                onError: (errors) => {
                    displayAlert({
                        type: "error",
                        message: errors.data || "Error al eliminar",
                    });
                },
            });
        }
    }

    $: console.log("selectedRow", selectedRow);
</script>

<section class="bg-background min-h-screen">
    <Alert />
    <div class="container mx-auto">
        <button
            class="btn inline-block"
            on:click={(e) => {
                if (submitStatus === "Editar") {
                    $form.reset();
                    editingUser = null;
                    selectedRow = { status: false, data: {} };
                }
                submitStatus = "Crear";
                showModal = true;
            }}>Crear nuevo personal</button
        >
        <!-- List -->

        <Table
            {selectedRow}
            allowFilters={false}
            filtersOptions={{}}
            serverSideData={{ filters: {} }}
            pagination={false}
            on:fillFormToEdit={handleEdit}
            on:clickDeleteIcon={handleDelete}
        >
            <thead slot="thead" class="sticky top-0 z-50">
                <tr>
                    <th>N°</th>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>Cédula de identidad</th>
                    <th>Correo electrónico</th>
                    <th>Número de teléfono</th>
                    <th class="max-w-[200px]">Dirección</th>
                    <th class="max-w-[200px]">Es administrador</th>
                </tr>
            </thead>
            <tbody slot="tbody">
                {#each data as user}
                    <SelectableRow
                        rowData={user}
                        idKey="id"
                        {selectedRow}
                        activeClass="bg-gray-200"
                        inactiveClass="hover:bg-gray-100"
                        on:select={(e) => { selectedRow = e.detail; }}
                    >
                        <td>{user.id}</td>
                        <td>{user.name}</td>
                        <td>{user.last_name}</td>
                        <td>{user.ci}</td>
                        <td>{user.email}</td>
                        <td>{user.phone_number}</td>
                        <td class="max-w-[200px] truncate" title={user.address}
                            >{user.address}</td
                        >
                        <td class="max-w-[200px]">
                            {#if user.is_admin}
                                Si
                            {:else}
                                No
                            {/if}
                        </td>
                    </SelectableRow>
                {/each}
            </tbody>
        </Table>
    </div>
</section>

<Modal bind:showModal modalClasses={"max-w-[560px]"}>
    <form
        id="a-form"
        on:submit={handleSubmit}
        action=""
        class="max-w-[1260px] gap-x-10 grid grid-cols-2 pt-2 px-7"
    >
        <Input
            label="Nombre"
            type="text"
            required={true}
            bind:value={$form.name}
            error={$form.errors.name}
        />
        <Input
            label="Apellido"
            type="text"
            required={true}
            bind:value={$form.last_name}
            error={$form.errors.last_name}
        />
        <Input
            label="Cédula de identidad"
            type="text"
            required={true}
            bind:value={$form.ci}
            error={$form.errors.ci}
        />
        <Input
            label="Correo electrónico"
            type="email"
            required={true}
            bind:value={$form.email}
            error={$form.errors.email}
        />
        <Input
            label="Número de teléfono"
            type="text"
            required={true}
            bind:value={$form.phone_number}
            error={$form.errors.phone_number}
        />
        <Input
            label="Dirección"
            type="textarea"
            required={true}
            bind:value={$form.address}
            error={$form.errors.address}
        />

        <div class="col-span-2 flex items-center gap-2 mt-2">
            <input
                id="is_admin"
                type="checkbox"
                bind:checked={$form.is_admin}
                class="w-4 h-4 text-green bg-gray-100 border-gray-300 rounded focus:ring-green/50 focus:ring-2"
            />
            <label for="is_admin" class="text-sm font-medium text-gray-900"
                >¿Es administrador?</label
            >
        </div>
        <button
            type="submit"
            class="btn btn-green col-span-2 mt-7 flex items-center justify-center gap-3"
            disabled={$form.processing}
        >
            {#if $form.processing}
                Cargando...
            {:else}
                <iconify-icon
                    icon="material-symbols:save-sharp"
                    width="24"
                    height="24"
                />
                <span> Guardar </span>
            {/if}
        </button>
    </form>
</Modal>

<style>
</style>
